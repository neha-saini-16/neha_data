2019-10-04: Marek Rydzy did some great work changing Naive Bayes and turning it into Log Probabilities to avoid
underflows
