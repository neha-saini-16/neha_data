This data was collected on May 7th 2015 using the [King County assessor site](http://www.kingcounty.gov/depts/assessor.aspx).

