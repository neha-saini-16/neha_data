# dependencies

numpy beautifulsoup4 theanets nose_parameterized

# for tests

## single test

`python -m unittest tests.test_language`

### all tests

`python -m unittest discover tests`