print("Hello World!")
print("make sure to use the same type of quotes(quotation marks or apostrophes)at the end that you used at the start")

# in c -> printf("Hello World!");
# in java -> System.out.println("Hello World!");
# in c++ -> cout << "Hello World";
# in javascript - > console.log("Hello World");
