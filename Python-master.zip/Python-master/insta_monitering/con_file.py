host = "localhost"
mongoPort = 27017
SOCKS5_PROXY_PORT = 1080
auth = ""
passcode = ""

# if proxy is not working please update the auth and passcode
