# Windows Wallpaper Script
Ever seen those amazing windows wallpapers on your windows lock screen? This Python Script will Import all of those amazing wallpapers into the current folder that the script is in.
The wallpapers keep changing with time when connected to the internet so you can run the script after you notice new wallpapers on your lockscreen in order to obtain them.

***Optional:*** You can also use the windows task scheduler and schedule
the script to run in a set time interval and also set the desktop wallpaper folder as default wallpaper folder. For more Info on task scheduling in Windows 10, 
Look Here: [Task Scheduling in windows](https://www.digitalcitizen.life/how-create-task-basic-task-wizard)

# Requirements
 * A Windows 10 PC
 * Python 3x
 * PIL Module For Python 3x

# Procedure
 * Run the script and enjoy!
